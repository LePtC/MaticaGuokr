Paclet[
	Name -> "WordData_InflectedForms",
	Version -> "10.0.25",
	MathematicaVersion->"10.0+",
	BackwardCompatible->"*",
	Extensions -> {
		{"Resource", Root -> "Data", Resources -> {"InflectedForms.wdx"} }
	}		
]