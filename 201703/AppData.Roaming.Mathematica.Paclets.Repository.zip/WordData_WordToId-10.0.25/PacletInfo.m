Paclet[
	Name -> "WordData_WordToId",
	Version -> "10.0.25",
	MathematicaVersion->"10.0+",
	BackwardCompatible->"*",
	Extensions -> {
		{"Resource", Root -> "Data", Resources -> {"WordToId.wdx"} }
	}		
]