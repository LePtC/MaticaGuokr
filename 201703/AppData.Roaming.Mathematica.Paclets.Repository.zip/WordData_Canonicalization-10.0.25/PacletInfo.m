Paclet[
	Name -> "WordData_Canonicalization",
	Version -> "10.0.25",
	MathematicaVersion->"10.0+",
	BackwardCompatible->"*",
	Extensions -> {
		{"Resource", Root -> "Data", Resources -> {"Canonicalization.wdx"} }
	}		
]