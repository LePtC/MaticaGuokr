Paclet[
	Name -> "WordData_Definitions",
	Version -> "10.0.25",
	MathematicaVersion->"10.0+",
	BackwardCompatible->"*",
	Extensions -> {
		{"Resource", Root -> "Data", Resources -> {"Definitions.wdx"} }
	}		
]