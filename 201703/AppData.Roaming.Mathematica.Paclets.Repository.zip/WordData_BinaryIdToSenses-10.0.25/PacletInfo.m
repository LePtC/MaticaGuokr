Paclet[
	Name -> "WordData_BinaryIdToSenses",
	Version -> "10.0.25",
	MathematicaVersion->"10.0+",
	BackwardCompatible->"*",
	Extensions -> {
		{"Resource", Root -> "Data", Resources -> {"BinaryIdToSenses.wdx"} }
	}		
]